rm -rf out* slurm* build/ CMake* opensbli* nodes* def* latex* Op* MPI* CUDA HIP* 
